import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Enemy {
	int x;
	int y;
	int h;
	int w;
	int speed;
	ImageIcon img ;
	Enemy(){
		speed = 15;
		y = 10;
		x = 1500/2;
		h = 200;
		w = 200;
		img = new ImageIcon(Enemy.class.getResource("spider.gif"));
	}
	void move() {
		if(y>900) {
			y = 0;
		}
		y = y + speed;
	}
	void printEnemy(Graphics pen) {
		pen.drawImage(img.getImage(), x, y, w, h, null);
	}
}
