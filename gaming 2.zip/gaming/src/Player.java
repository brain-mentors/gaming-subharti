import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Player {
	int x;
	int y;
	int h;
	int w;
	int speed;
	
	ImageIcon img ;
	Player(){
		speed = 0;
		x = 70;
		h = w = 200;
		y = 900-50-h;
		img = new ImageIcon(Player.class.getResource("player.gif"));
	}
	void move() {
		x = x + speed;
	}
	void printPlayer(Graphics pen) {
		pen.drawImage(img.getImage(), x, y, w, h, null);
		
	}
	
}
