import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

// All Painting Happens Here
// Show Image
public class Board extends JPanel {
	
	BufferedImage backgroundImage;
	
	public Board(){
		try {
		backgroundImage = ImageIO.
				read(Board.class.getResource("background.jpg"));
		}
		catch(Exception e) {
			System.out.println("No Background Image Exist ");
			System.exit(0);
		}
		}
	 
	
	@Override
	public void paintComponent(Graphics pen) {
		super.paintComponent(pen);
		pen.drawImage(backgroundImage,0,0,1500,900,null);
		
	}

}








