import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Player {
	int x;
	int y;
	int h;
	int w;
	ImageIcon img ;
	Player(){
		img = new ImageIcon(Player.class.getResource("player.gif"));
	}
	void printPlayer(Graphics pen) {
		
	}
	
}
