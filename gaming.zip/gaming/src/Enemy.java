import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Enemy {
	int x;
	int y;
	int h;
	int w;
	ImageIcon img ;
	Enemy(){
		img = new ImageIcon(Enemy.class.getResource("spider.gif"));
	}
	void printEnemy(Graphics pen) {
		
	}
}
