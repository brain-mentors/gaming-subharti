import javax.swing.JFrame;

public class GameFrame extends JFrame {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GameFrame obj = new GameFrame(); // object create
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		obj.setSize(1500, 900);
		obj.setResizable(false);
		obj.setTitle("My Game -2023");
		Board board = new Board();
		obj.add(board);
		obj.setVisible(true);
		

	}

}



